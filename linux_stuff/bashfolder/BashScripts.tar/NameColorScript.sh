#!/bin/bash
echo "Hello, Whats your name?"

read name

echo "What is your favorite color?"

read color

echo "Welcome" $name "I can see your favorit color is" $color "I whish you a happy day!"